﻿using System;

namespace AbbreviateThis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Abbreviate This ...\n");

            Abbreviator abbreviator = new Abbreviator();

            string sentence = "Laughing Out Loud";
            string result = abbreviator.Abbreviate(sentence);

            Console.WriteLine($"{result} means {sentence}");

            Console.ReadLine();
        }
    }
}