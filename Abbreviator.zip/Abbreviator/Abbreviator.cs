using System;

namespace AbbreviateThis
{
    public class Abbreviator
    {
        public string Abbreviate(string text)
        {
            // If the string is empty or null, return empty string
            if (string.IsNullOrWhiteSpace(text))
                return string.Empty;

            string[] words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string abbreviation = string.Empty;

            foreach (string word in words)
            {
                abbreviation += char.ToUpper(word[0]);
            }

            return abbreviation;
        }
    }
}