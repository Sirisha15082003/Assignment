﻿using System;

namespace BackToTheFuture
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Back to the Future.\n");
            Console.WriteLine("Here we are demonstrating a TimeStamp class.\n");

            TimeStamp first = new TimeStamp();
            TimeStamp second = new TimeStamp(13, 12, 11);

            Console.WriteLine($"Default construction: {first}");
            Console.WriteLine($"With timing info: {second}\n");

            first.AddHours(12);
            second.AddHours(12);
            Console.WriteLine($"Let's set the hours 12h ahead: {first} or for the second {second}");

            first.AddMinutes(66);
            second.AddMinutes(66);
            Console.WriteLine($"Let's set the minutes 66m ahead: {first} or for the second {second}");

            first.AddSeconds(138);
            second.AddSeconds(138);
            Console.WriteLine($"Let's set the seconds 138s ahead: {first} or for the second {second}");

            Console.ReadLine();
        }
    }
}