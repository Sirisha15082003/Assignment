using System;

namespace BackToTheFuture
{
    public class TimeStamp
    {
        private int _hours;
        private int _minutes;
        private int _seconds;

        public int Hours
        {
            get => _hours;
            set
            {
                _hours = value < 0 ? 0 : value;
                Normalize();
            }
        }

        public int Minutes
        {
            get => _minutes;
            set
            {
                _minutes = value < 0 ? 0 : value;
                Normalize();
            }
        }

        public int Seconds
        {
            get => _seconds;
            set
            {
                _seconds = value < 0 ? 0 : value;
                Normalize();
            }
        }

        // Default constructor
        public TimeStamp()
        {
            Hours = 0;
            Minutes = 0;
            Seconds = 0;
        }

        // Constructor with time info
        public TimeStamp(int hours, int minutes, int seconds)
        {
            _hours = hours < 0 ? 0 : hours;
            _minutes = minutes < 0 ? 0 : minutes;
            _seconds = seconds < 0 ? 0 : seconds;
            Normalize();
        }

        // Normalize overflow values
        private void Normalize()
        {
            _minutes += _seconds / 60;
            _seconds %= 60;

            _hours += _minutes / 60;
            _minutes %= 60;

            _hours %= 24;
        }

        public void AddSeconds(int seconds)
        {
            if (seconds < 0) return;
            _seconds += seconds;
            Normalize();
        }

        public void AddMinutes(int minutes)
        {
            if (minutes < 0) return;
            _minutes += minutes;
            Normalize();
        }

        public void AddHours(int hours)
        {
            if (hours < 0) return;
            _hours += hours;
            Normalize();
        }

        public override string ToString()
        {
            return $"{Hours}h {Minutes}m {Seconds}s";
        }
    }
}