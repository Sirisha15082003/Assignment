﻿using System;

namespace GeneratorOfNumbers
{
    // Interface definition
    public interface IGenerator
    {
        int Next();
        void Reset();
    }

    // Natural numbers generator: 0,1,2,3...
    public class NaturalGenerator : IGenerator
    {
        private int _current = -1;

        public int Next()
        {
            _current++;
            return _current;
        }

        public void Reset()
        {
            _current = -1;
        }
    }

    // Powers of two generator: 1,2,4,8...
    public class PowersOfTwoGenerator : IGenerator
    {
        private int _current = 1;
        private bool _firstCall = true;

        public int Next()
        {
            if (_firstCall)
            {
                _firstCall = false;
                return _current;
            }

            _current *= 2;
            return _current;
        }

        public void Reset()
        {
            _current = 1;
            _firstCall = true;
        }
    }

    // Fibonacci sequence generator: 1,1,2,3,5...
    public class FibonacciGenerator : IGenerator
    {
        private int _previous = 0;
        private int _current = 1;

        public int Next()
        {
            int next = _previous + _current;
            _previous = _current;
            _current = next;
            return _previous;
        }

        public void Reset()
        {
            _previous = 0;
            _current = 1;
        }
    }

    // Random number generator
    public class RandomGenerator : IGenerator
    {
        private readonly Random _random;
        private readonly int _seed;

        public RandomGenerator(int seed)
        {
            _seed = seed;
            _random = new Random(seed);
        }

        public int Next()
        {
            return _random.Next();
        }

        public void Reset()
        {
            // Reset using the same seed to reproduce the same sequence
            typeof(Random).GetField("_seedArray",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(_random, null);

            typeof(Random).GetField("_inext",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(_random, 0);

            typeof(Random).GetField("_inextp",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(_random, 21);

            new Random(_seed);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Generator of Numbers.\n");

            // Uncomment blocks below to test

            TestGenerator("Series of natural numbers:", new NaturalGenerator());
            TestGenerator("Powers of two:", new PowersOfTwoGenerator());
            TestGenerator("Fibonacci Sequence:", new FibonacciGenerator());

            var randomGen = new RandomGenerator(42);
            TestGenerator("Random series of numbers:", randomGen);
            TestGenerator("", randomGen);

            Console.ReadLine();
        }

        private static void TestGenerator(string title, IGenerator generator)
        {
            if (!string.IsNullOrEmpty(title))
                Console.WriteLine(title);

            generator.Reset();

            for (int i = 0; i < 20; i++)
            {
                Console.Write(generator.Next() + " ");
            }

            Console.WriteLine("\n");
        }
    }
}