﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        Console.WriteLine("Starting downloads...\n");

        var urls = Enumerable.Range(1, 1000)
            .Select(i => $"https://example.com/resource/{i}")
            .ToList();

        try
        {
            await DownloadAllWithThrottlingAsync(urls, maxConcurrency: 5);
            Console.WriteLine("\nAll downloads completed successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("\nSome downloads failed.");
            Console.WriteLine(ex.Message);
        }
    }

    static async Task DownloadAllWithThrottlingAsync(
        IEnumerable<string> urls,
        int maxConcurrency)
    {
        using var semaphore = new SemaphoreSlim(maxConcurrency);
        using var httpClient = new HttpClient();

        var tasks = urls.Select(async url =>
        {
            await semaphore.WaitAsync();
            try
            {
                await DownloadAsync(httpClient, url);
            }
            finally
            {
                semaphore.Release();
            }
        });

        // Task.WhenAll waits for all tasks, even if some fail
        await Task.WhenAll(tasks);
    }

    static async Task DownloadAsync(HttpClient client, string url)
    {
        Console.WriteLine($"Downloading: {url}");

        // Simulate random failures
        await Task.Delay(300);

        if (Random.Shared.Next(0, 10) < 2)
        {
            throw new Exception($"Download failed for {url}");
        }

        // Example real download (commented for safety):
        // var response = await client.GetAsync(url);
        // response.EnsureSuccessStatusCode();

        Console.WriteLine($"Completed: {url}");
    }
}