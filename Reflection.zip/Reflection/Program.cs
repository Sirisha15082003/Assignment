﻿using System;
using System.Reflection;
 
namespace ReflectionDemo
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            Assembly asm = Assembly.GetExecutingAssembly();

            var plugins =
                asm.GetTypes()
                   .Where(t => typeof(IPlugin).IsAssignableFrom(t)
                               && t.IsClass && !t.IsAbstract
                               && t.GetConstructor(Type.EmptyTypes) != null)
                   .Select(t => (IPlugin)Activator.CreateInstance(t)!)
                   .OrderBy(p => p.Name); 

            foreach (var plugin in plugins)
            {
                Console.WriteLine($"Running: {plugin.Name}");
                plugin.Execute();
            }
        }
    }
}