using System;

namespace ReflectionDemo
{
    public interface IPlugin
    {
        string Name { get; }
        void Execute();
    }
}