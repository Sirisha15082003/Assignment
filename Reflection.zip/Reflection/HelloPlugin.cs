using System;

namespace ReflectionDemo
{
    public sealed class HelloPlugin : IPlugin
    { 
        public string Name => "HelloPlugin";
        public void Execute() => Console.WriteLine("Hello Plugin Executed!");
    }
}