using System;

namespace ReflectionDemo
{
    public sealed class DatePlugin : IPlugin
        {
            public string Name => "DatePlugin";
            public void Execute() => Console.WriteLine("Today's Date: " + DateTime.Now);
        }

}