﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        Console.WriteLine("Starting concurrent configuration requests...\n");

        // Simulate many concurrent callers
        var tasks = Enumerable.Range(1, 10)
            .Select(i => Task.Run(async () =>
            {
                var config = await ConfigurationProvider.GetConfigurationAsync();
                Console.WriteLine($"Task {i} received config: {config.Value}");
            }));

        await Task.WhenAll(tasks);

        Console.WriteLine("\nAll tasks completed.");
    }
}

// ---------------- CONFIGURATION ----------------

public class Configuration
{
    public string Value { get; }

    public Configuration(string value)
    {
        Value = value;
    }
}

// ---------------- ASYNC SINGLETON ----------------

public static class ConfigurationProvider
{
    private static Configuration? _instance;
    private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

    public static async Task<Configuration> GetConfigurationAsync()
    {
        // Fast path (already initialized)
        if (_instance != null)
            return _instance;

        await _semaphore.WaitAsync();
        try
        {
            // Double-check inside semaphore
            if (_instance == null)
            {
                Console.WriteLine("Loading configuration from database...");
                _instance = await LoadConfigurationFromDatabaseAsync();
                Console.WriteLine("Configuration loaded.\n");
            }
        }
        finally
        {
            _semaphore.Release();
        }

        return _instance;
    }

    private static async Task<Configuration> LoadConfigurationFromDatabaseAsync()
    {
        // Simulate expensive async operation
        await Task.Delay(2000);
        return new Configuration("Database_Config_Value");
    }
}