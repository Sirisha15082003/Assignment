﻿using System;
using System.Data;
using System.Data.SqlClient;

class Program
{
    static string connectionString = "Server=LTPBAN342663562\\SQLEXPRESS;Database=CompanyDB;Trusted_Connection=True;TrustServerCertificate=True;";

    static void Main()
    {
       while(true)
       {
        System.Console.WriteLine("\n=== Department Management ===\n");
        System.Console.WriteLine("1. Insert");
        System.Console.WriteLine("2. Update");
        System.Console.WriteLine("3. Delete");
        System.Console.WriteLine("4. View All");
        System.Console.WriteLine("5. Exit");
        System.Console.WriteLine("Choose an Option: ");

        int choice = Convert.ToInt32(Console.ReadLine());
        switch(choice)
        {
            case 1: InsertDepartment();
            break;
            case 2: UpdateDepartment();
            break;
            case 3: DeleteDepartment();
            break;
            case 4: GetDepartments();
            break;
            case 5: return;
            default: Console.WriteLine("Invalid choice"); break;
        }
       }
    }

    static void InsertDepartment()
    {
        System.Console.WriteLine("Enter ID: ");
        int id = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("Enter Name: ");
        string name = Console.ReadLine();
        using(SqlConnection conn = new SqlConnection(connectionString))
        using(SqlCommand cmd = new SqlCommand("sp_InsertDepartment", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@Name", name);
            conn.Open();

            int rows = cmd.ExecuteNonQuery();
            System.Console.WriteLine(rows > 0 ? "Inserted Successfully": "Insert Failed");
        }
    }


    static void UpdateDepartment()
    {
        System.Console.WriteLine("Enter ID: ");
        int id = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("Enter New Name: ");
        string name = Console.ReadLine();
        using(SqlConnection conn = new SqlConnection(connectionString))
        using(SqlCommand cmd = new SqlCommand("sp_UpdateDepartment", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@Name", name);
            conn.Open();

            int rows = cmd.ExecuteNonQuery();
            System.Console.WriteLine(rows > 0 ? "Updated Successfully": "No Record Found!");
        }
    }

    static void DeleteDepartment()
    {
        System.Console.WriteLine("Enter ID: ");
        int id = Convert.ToInt32(Console.ReadLine());
        
        using(SqlConnection conn = new SqlConnection(connectionString))
        using(SqlCommand cmd = new SqlCommand("sp_DelteDepartment", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", id);
            conn.Open();

            int rows = cmd.ExecuteNonQuery();
            System.Console.WriteLine(rows > 0 ? "Deleted Successfully": "No Record Found!");
        }
    }

    static void GetDepartments()
    {
        using(SqlConnection conn = new SqlConnection(connectionString))
        using(SqlCommand cmd = new SqlCommand("sp_GetDepartments", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            using(SqlDataReader reader = cmd.ExecuteReader())
            {
                System.Console.WriteLine("\n--- Departments ---");
                while(reader.Read())
                {
                    System.Console.WriteLine($"ID: {reader["Id"]}, Name: {reader["Name"]}");
                }
            }
        }
    }
}
