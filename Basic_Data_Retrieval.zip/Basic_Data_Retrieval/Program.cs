﻿using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        System.Console.WriteLine("=== Employee Fetch by Department ===");
        System.Console.WriteLine("Enter Department ID: ");

        int deptId = Convert.ToInt32(Console.ReadLine());

        string connectionString = "Server=LTPBAN342663562\\SQLEXPRESS;Database=CompanyDB;Trusted_Connection=True;";

        try
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT Id, Name, Salary 
                                FROM Employees WHERE
                                DepartmentId = @DeptId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DeptId", deptId);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if(!reader.HasRows)
                        {
                            System.Console.WriteLine("\nNo Employees found for this Department!");
                            return;
                        }
                        System.Console.WriteLine("\n--- Employee List ---\n");

                        while(reader.Read())
                        {
                            System.Console.WriteLine($"ID: {reader["Id"]}");
                            System.Console.WriteLine($"Name: {reader["Name"]}");
                            System.Console.WriteLine($"Salary: {reader["Salary"]}");
                            System.Console.WriteLine("--------------------------------------------------");
                        }
                    }
                }
            }
        }
        catch(SqlException ex)
        {
            System.Console.WriteLine("Database Error: " + ex.Message);
        }
        catch(Exception ex)
        {
            System.Console.WriteLine("General Error: " + ex.Message);
        }

    }
}
