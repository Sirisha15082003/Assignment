﻿// using System;
 
// class Matrix
// {
//     private int[,] data = new int[3,3];
 
//     // Indexer with bounds checking
//     public int this[int row, int column]
//     {
//         get
//         {
//             if (row >= 0 && row < 3 && column >= 0 && column < 3)
//             {
//                 return data[row, column];
//             }
//             else
//             {
//                 throw new IndexOutOfRangeException("Invalid index!");
//             }
//         }
 
//         set
//         {
//             if (row >= 0 && row < 3 && column >= 0 && column < 3)
//             {
//                 data[row, column] = value;
//             }
//             else
//             {
//                 throw new IndexOutOfRangeException("Invalid index!");
//             }
//         }
//     }
// }
 
// class Program
// {
//     static void Main()
//     {
//         Matrix m = new Matrix();
 
//         m[0,0] = 10;
//         m[1,1] = 20;
 
//         Console.WriteLine(m[0,0]);
//         Console.WriteLine(m[1,1]);
 
//         // This will cause an error because index is out of range
//         Console.WriteLine(m[5,5]);
//     }
// }


using System;
 
class Matrix
{
    private int[,] data = new int[3,3];   // 2D array
 
    // Indexer
    public int this[int row, int column]
    {
        get
        {
            return data[row, column];
        }
        set
        {
            data[row, column] = value;
        }
    }
}
 
class Program
{
    static void Main()
    {
        Matrix m = new Matrix();
 
        // Setting values using indexer
        m[0,0] = 10;
        m[0,1] = 20;
        m[1,0] = 30;
        m[1,1] = 40;
 
        // Getting values using indexer
        Console.WriteLine("Value at [0,0]: " + m[0,0]);
        Console.WriteLine("Value at [0,1]: " + m[0,1]);
        Console.WriteLine("Value at [1,0]: " + m[1,0]);
        Console.WriteLine("Value at [1,1]: " + m[1,1]);
    }
}
 